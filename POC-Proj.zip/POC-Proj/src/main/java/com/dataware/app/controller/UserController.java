package com.dataware.app.controller;

import javax.naming.AuthenticationException;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dataware.app.model.UserInfo;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	
	
	
	@GetMapping("/login")
	public Object login(@RequestParam("username") String username,@RequestParam("password") String password ) {
		Object str = null;
		try {
		if(username.equals("ramesh") && password.equals("ramesh")) {
			str = "Welcome "+username;
		}else {
			str = "login failed";
			throw new AuthenticationException();
		}
		}catch(Exception e) {
			e.printStackTrace();
			return new AuthenticationException();
		}
		
		return str;
	}

	
	
	@GetMapping("/userdetails")
	public UserInfo getUserDetails() {
		UserInfo user = new UserInfo();;
		
			user.setDisplayName("Ramesh");
			user.setUserName("ramesh");
			user.setEmail("ss@gmail.com");
			user.setGender("Male");
			user.setContact("0000232");
			user.setDob("01 Apr ");
			
		
		return user;
	}

	
}
